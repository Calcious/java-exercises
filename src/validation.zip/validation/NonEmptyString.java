package validation;

/**
 * Created by Moravia on 12/2/16.
 */
public class NonEmptyString {
}
